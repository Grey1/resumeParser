from flask import Blueprint
from flask import request
from .services.file_upload_service import upload_files
from flask import current_app as app


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        f = request.files.getlist['resumes']
        upload_files(f)
        