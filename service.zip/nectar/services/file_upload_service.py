import os
from flask import current_app as app
from ..models import Resume,db
from datetime import datetime as dt

def upload_files(files):
    for file in files:
        try:
            upload_file(file)
        except:
            return False
    

def upload_file(file):
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
    